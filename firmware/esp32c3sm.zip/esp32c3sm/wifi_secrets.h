#pragma once


struct WifiHotspots
{
    const char *ssid;
    const char *password;
};

WifiHotspots wifihotspots[] = {
    {"alpha", "centauri"},
    // {"alpha13", "centauri"},
    {"alpha2", "centauri"},
};
